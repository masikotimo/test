<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end mb-2">
<a href="<?php echo e(route('category.create')); ?>" class="btn btn-success float-right">Add Category</a></div>
<div class="card card-default">
<div class="card-header">
Categories
</div>

<div class="card-body">
<table class="table table-light">
    <thead>
    Name
    </thead>
    <thead>
    
    </thead>
    <tbody>

    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
            <td><?php echo e($cate->name); ?></td>
            <td>
            <a href="<?php echo e(route('category.edit',$cate->id)); ?>" class="btn-btn-info-sm">Edit</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/timothy/Transcend/cms/resources/views/categories/index.blade.php ENDPATH**/ ?>