@extends('layouts.app')


@section('content')
<div class="d-flex justify-content-end mb-2">
<a href="{{route('category.create')}}" class="btn btn-success float-right">Add Category</a></div>
<div class="card card-default">
<div class="card-header">
Categories
</div>

<div class="card-body">
<table class="table table-light">
    <thead>
    Name
    </thead>
    <thead>
    
    </thead>
    <tbody>

    @foreach($cat as $cate)
    <tr>
            <td>{{$cate->name}}</td>
            <td>
            <a href="{{route('category.edit',$cate->id)}}" class="btn-btn-info-sm">Edit</a>
            </td>
        </tr>
    @endforeach
        
    </tbody>
</table>
</div>
</div>

@endsection